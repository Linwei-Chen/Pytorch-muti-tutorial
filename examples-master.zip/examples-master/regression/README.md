# Linear regression example

Trains a single fully-connected layer to fit a 4th degree polynomial.
